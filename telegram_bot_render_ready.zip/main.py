from telegram.ext import ApplicationBuilder, CommandHandler
import asyncio
import logging
import os

BOT_TOKEN = os.getenv("BOT_TOKEN")

logging.basicConfig(level=logging.INFO)

async def start(update, context):
    await update.message.reply_text("Hello! I’m your bot and I’m running on Render!")

async def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))

    await app.initialize()
    await app.start()
    print("Bot is running...")

    await asyncio.Event().wait()

if __name__ == '__main__':
    asyncio.run(main())
